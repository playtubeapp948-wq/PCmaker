P.Cmaker - Android Studio starter project

खोलने का तरीका:
1. ZIP extract करें।
2. Android Studio में File > Open चुनें और PCmaker folder खोलें।
3. Gradle sync पूरा होने दें।
4. Android फोन/एम्युलेटर जोड़कर Run दबाएँ।

इस starter build में काम करने वाले भाग:
- Gallery से image चुनना
- Brightness और contrast adjustment
- 90-degree rotate control
- Edited image को Pictures/P.Cmaker में save करना
- चुनी हुई image से PDF बनाना
- Text से PDF बनाना
- बने PDF की सूची देखना और share करना
- Dark UI, Home, Editor, My Files, Tools, Settings

अभी अगले development चरण में जोड़ने वाले advanced modules:
- Multi-PDF merge / split / compression
- OCR और auto edge detection वाला camera scanner
- PDF page rotation, password protection
- Crop handles, filters, background cleanup
- Batch processing और Hindi localization

महत्वपूर्ण:
यह एक starter source project है; इस environment में Android Gradle build चलाकर APK verify नहीं किया गया है।
असली बैंक/सरकारी/पहचान दस्तावेज़ की सामग्री, फोटो, मुहर या आधिकारिक निशान बदलने/नकली बनाने के लिए इसका उपयोग न करें।
