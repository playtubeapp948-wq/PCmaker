package com.pcmaker.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.content.ContentValues
import android.content.Intent
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color as ComposeColor
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

private val Navy = ComposeColor(0xFF10132B)
private val Panel = ComposeColor(0xFF1B2042)
private val Purple = ComposeColor(0xFF8B5CF6)
private val Cyan = ComposeColor(0xFF22D3EE)
private val White = ComposeColor(0xFFF7F7FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PCmakerApp() }
    }
}

data class SavedItem(val name: String, val file: File)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PCmakerApp() {
    val context = LocalContext.current
    var tab by remember { mutableStateOf("Home") }
    var selectedImage by remember { mutableStateOf<Bitmap?>(null) }
    var selectedName by remember { mutableStateOf("No image selected") }
    var status by remember { mutableStateOf("Welcome to P.Cmaker") }
    var brightness by remember { mutableFloatStateOf(1f) }
    var contrast by remember { mutableFloatStateOf(1f) }
    var rotation by remember { mutableIntStateOf(0) }
    var textForPdf by remember { mutableStateOf("My document") }
    var pdfs by remember { mutableStateOf(listOf<SavedItem>()) }

    fun loadPdfFiles() {
        val dir = context.getExternalFilesDir("Documents")
        pdfs = dir?.listFiles()?.filter { it.extension.equals("pdf", true) }
            ?.sortedByDescending { it.lastModified() }
            ?.map { SavedItem(it.name, it) } ?: emptyList()
    }
    LaunchedEffect(Unit) { loadPdfFiles() }

    val imagePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    selectedImage = BitmapFactory.decodeStream(stream)
                }
                selectedName = "Selected image"
                status = "Image loaded. Use Enhance or Create PDF."
                tab = "Editor"
            } catch (_: Exception) { status = "Could not open this image." }
        }
    }

    val pdfPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            status = "PDF selected. Advanced PDF editing tools can be added in the next build."
        }
    }

    fun getEnhancedBitmap(): Bitmap? {
        val src = selectedImage ?: return null
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        val b = brightness
        val c = contrast
        val scale = c
        val translate = 128f * (1f - c) + (b - 1f) * 255f
        val matrix = android.graphics.ColorMatrix(floatArrayOf(
            scale,0f,0f,0f,translate,
            0f,scale,0f,0f,translate,
            0f,0f,scale,0f,translate,
            0f,0f,0f,1f,0f
        ))
        paint.colorFilter = android.graphics.ColorMatrixColorFilter(matrix)
        val save = canvas.save()
        canvas.rotate(rotation.toFloat(), src.width / 2f, src.height / 2f)
        canvas.drawBitmap(src, 0f, 0f, paint)
        canvas.restoreToCount(save)
        return out
    }

    fun createPdfFromImage() {
        val bitmap = getEnhancedBitmap()
        if (bitmap == null) { status = "Please upload an image first."; return }
        try {
            val doc = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
            val page = doc.startPage(pageInfo)
            val canvas = page.canvas
            val margin = 24f
            val scale = minOf((595f - margin * 2) / bitmap.width, (842f - margin * 2) / bitmap.height)
            val w = bitmap.width * scale
            val h = bitmap.height * scale
            val left = (595f - w) / 2f
            val top = (842f - h) / 2f
            canvas.drawColor(Color.WHITE)
            canvas.drawBitmap(bitmap, null, RectF(left, top, left + w, top + h), Paint(Paint.ANTI_ALIAS_FLAG))
            doc.finishPage(page)
            val dir = context.getExternalFilesDir("Documents") ?: context.filesDir
            dir.mkdirs()
            val file = File(dir, "PCmaker_${System.currentTimeMillis()}.pdf")
            FileOutputStream(file).use { doc.writeTo(it) }
            doc.close()
            loadPdfFiles()
            status = "PDF created: ${file.name}"
        } catch (e: Exception) { status = "PDF creation failed: ${e.message}" }
    }

    fun saveEnhancedImage() {
        val bitmap = getEnhancedBitmap()
        if (bitmap == null) { status = "Please upload an image first."; return }
        try {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "PCmaker_${System.currentTimeMillis()}.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/P.Cmaker")
            }
            val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                context.contentResolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                status = "Enhanced image saved to Pictures/P.Cmaker"
            } else status = "Could not save image."
        } catch (e: Exception) { status = "Save failed: ${e.message}" }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Purple, secondary = Cyan, background = Navy,
            surface = Panel, onPrimary = White, onBackground = White, onSurface = White
        )
    ) {
        Scaffold(
            containerColor = Navy,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("P.Cmaker", fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                            Text("PDF • Card • Photo • Documents", fontSize = 11.sp, color = Cyan)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy, titleContentColor = White),
                    actions = { Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Cyan, modifier = Modifier.padding(end = 18.dp)) }
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = White) {
                    listOf("Home", "Editor", "My Files", "Tools", "Settings").forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = {
                                Icon(when(item) {
                                    "Home" -> Icons.Default.Home
                                    "Editor" -> Icons.Default.Tune
                                    "My Files" -> Icons.Default.Folder
                                    "Tools" -> Icons.Default.Build
                                    else -> Icons.Default.Settings
                                }, contentDescription = item)
                            },
                            label = { Text(item, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Cyan, selectedTextColor = Cyan,
                                indicatorColor = Purple.copy(alpha = .22f),
                                unselectedIconColor = White.copy(alpha = .65f),
                                unselectedTextColor = White.copy(alpha = .65f)
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
                when (tab) {
                    "Home" -> HomeScreen(
                        onUpload = { imagePicker.launch("image/*") },
                        onPdf = { imagePicker.launch("image/*") },
                        onScan = { imagePicker.launch("image/*") },
                        onOpenPdf = { pdfPicker.launch(arrayOf("application/pdf")) },
                        onTools = { tab = "Tools" },
                        status = status
                    )
                    "Editor" -> EditorScreen(
                        image = getEnhancedBitmap(),
                        imageName = selectedName,
                        brightness = brightness,
                        contrast = contrast,
                        rotation = rotation,
                        onBrightness = { brightness = it },
                        onContrast = { contrast = it },
                        onRotate = { rotation = (rotation + 90) % 360 },
                        onUpload = { imagePicker.launch("image/*") },
                        onSave = { saveEnhancedImage() },
                        onCreatePdf = { createPdfFromImage() },
                        status = status
                    )
                    "My Files" -> FilesScreen(pdfs, onRefresh = { loadPdfFiles() }, onShare = { file ->
                        try {
                            val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "application/pdf"; putExtra(Intent.EXTRA_STREAM, uri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(Intent.createChooser(intent, "Share PDF"))
                        } catch (_: Exception) { status = "Unable to share this file." }
                    })
                    "Tools" -> ToolsScreen(
                        onCreate = { imagePicker.launch("image/*") },
                        onOpenPdf = { pdfPicker.launch(arrayOf("application/pdf")) },
                        onScan = { imagePicker.launch("image/*") },
                        onMerge = { status = "Choose PDFs to merge — multi-file merge is planned for the next build." },
                        onSplit = { status = "PDF split tool is planned for the next build." },
                        onCompress = { status = "PDF compression tool is planned for the next build." },
                        onText = { tab = "Text PDF" },
                        onImage = { imagePicker.launch("image/*") }
                    )
                    "Text PDF" -> TextPdfScreen(textForPdf, { textForPdf = it }, {
                        try {
                            val doc = PdfDocument()
                            val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
                            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; textSize = 18f }
                            val lines = textForPdf.lines()
                            var y = 60f
                            lines.forEach { line -> page.canvas.drawText(line.take(75), 42f, y, paint); y += 28f }
                            doc.finishPage(page)
                            val dir = context.getExternalFilesDir("Documents") ?: context.filesDir
                            dir.mkdirs()
                            val file = File(dir, "PCmaker_Text_${System.currentTimeMillis()}.pdf")
                            FileOutputStream(file).use { doc.writeTo(it) }; doc.close()
                            loadPdfFiles(); status = "Text PDF created."
                            tab = "My Files"
                        } catch (e: Exception) { status = "Could not create PDF: ${e.message}" }
                    })
                    else -> SettingsScreen()
                }
            }
        }
    }
}

@Composable
fun HomeScreen(onUpload: () -> Unit, onPdf: () -> Unit, onScan: () -> Unit, onOpenPdf: () -> Unit, onTools: () -> Unit, status: String) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(vertical = 14.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.fillMaxWidth().padding(20.dp)) {
                    Text("Your all-in-one creator", color = Cyan, fontSize = 13.sp)
                    Text("Make every page\nlook its best.", color = White, fontSize = 28.sp, fontWeight = FontWeight.Black)
                    Text("Create PDFs, scan documents and enhance photos.", color = White.copy(alpha = .7f))
                    Spacer(Modifier.height(14.dp))
                    Button(onClick = onUpload, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.CloudUpload, null); Spacer(Modifier.width(8.dp)); Text("Upload Photo / Card")
                    }
                }
            }
        }
        item { Text("Quick Actions", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                HomeTile("Create PDF", Icons.Default.PictureAsPdf, Modifier.weight(1f), onPdf)
                HomeTile("Scan Document", Icons.Default.DocumentScanner, Modifier.weight(1f), onScan)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                HomeTile("Edit Photo", Icons.Default.AutoFixHigh, Modifier.weight(1f), onUpload)
                HomeTile("Open PDF", Icons.Default.FolderOpen, Modifier.weight(1f), onOpenPdf)
            }
        }
        item { HomeTile("All PDF & Image Tools", Icons.Default.Build, Modifier.fillMaxWidth(), onTools) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Purple.copy(alpha = .18f))) {
                Text(status, Modifier.padding(14.dp), color = White, fontSize = 13.sp)
            }
        }
        item {
            Text("Privacy tip: P.Cmaker keeps generated files in your app storage unless you choose to share or save them.",
                color = White.copy(alpha = .55f), fontSize = 11.sp)
        }
    }
}

@Composable
fun HomeTile(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Card(modifier.clickable { onClick() }, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Cyan, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(10.dp))
            Text(title, color = White, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun EditorScreen(
    image: Bitmap?, imageName: String, brightness: Float, contrast: Float, rotation: Int,
    onBrightness: (Float) -> Unit, onContrast: (Float) -> Unit, onRotate: () -> Unit,
    onUpload: () -> Unit, onSave: () -> Unit, onCreatePdf: () -> Unit, status: String
) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(vertical = 14.dp)) {
        item { Text("Photo & Card Enhancer", fontSize = 22.sp, fontWeight = FontWeight.Bold) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                Box(Modifier.fillMaxWidth().height(260.dp).padding(12.dp), contentAlignment = Alignment.Center) {
                    if (image != null) Image(image.asImageBitmap(), null, modifier = Modifier.fillMaxSize())
                    else Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.AddPhotoAlternate, null, tint = Cyan, modifier = Modifier.size(54.dp))
                        Text("Upload a photo or card", color = White)
                    }
                }
            }
        }
        item { Button(onClick = onUpload, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Upload, null); Text("  Choose from Gallery") } }
        item { Text("Brightness  ${(brightness * 100).toInt()}%") }
        item { Slider(value = brightness, onValueChange = onBrightness, valueRange = .5f..1.8f) }
        item { Text("Contrast  ${(contrast * 100).toInt()}%") }
        item { Slider(value = contrast, onValueChange = onContrast, valueRange = .5f..1.8f) }
        item { OutlinedButton(onClick = onRotate, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.RotateRight, null); Text("  Rotate 90°  •  Current: ${rotation}°") } }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onSave, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Download, null); Text(" Save Image") }
                Button(onClick = onCreatePdf, modifier = Modifier.weight(1f)) { Icon(Icons.Default.PictureAsPdf, null); Text(" Make PDF") }
            }
        }
        item { Text(status, color = Cyan, fontSize = 12.sp) }
        item { Text("Note: enhancement changes brightness/contrast only; it does not reconstruct unreadable text or validate identity documents.", color = White.copy(alpha = .55f), fontSize = 11.sp) }
    }
}

@Composable
fun ToolsScreen(
    onCreate: () -> Unit, onOpenPdf: () -> Unit, onScan: () -> Unit,
    onMerge: () -> Unit, onSplit: () -> Unit, onCompress: () -> Unit,
    onText: () -> Unit, onImage: () -> Unit
) {
    val tools = listOf(
        Triple("Image to PDF", Icons.Default.Image, onCreate),
        Triple("Text to PDF", Icons.Default.TextFields, onText),
        Triple("Document Scan", Icons.Default.DocumentScanner, onScan),
        Triple("PDF Viewer", Icons.Default.PictureAsPdf, onOpenPdf),
        Triple("Merge PDFs", Icons.Default.Merge, onMerge),
        Triple("Split PDF", Icons.Default.CallSplit, onSplit),
        Triple("Compress PDF", Icons.Default.Compress, onCompress),
        Triple("Photo Enhancer", Icons.Default.AutoFixHigh, onImage)
    )
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 14.dp)) {
        item { Text("All Tools", fontSize = 23.sp, fontWeight = FontWeight.Bold) }
        item { Text("Choose a tool to get started.", color = White.copy(alpha = .65f)) }
        items(tools) { item -> HomeTile(item.first, item.second, Modifier.fillMaxWidth(), item.third) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Text("More tools planned: PDF page rotation, password protection, OCR text extraction, batch processing and advanced scanner edge detection.",
                    Modifier.padding(14.dp), color = White.copy(alpha = .75f), fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun FilesScreen(items: List<SavedItem>, onRefresh: () -> Unit, onShare: (File) -> Unit) {
    Column(Modifier.fillMaxSize().padding(vertical = 14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("My PDFs", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, null, tint = Cyan) }
        }
        if (items.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No PDFs yet.\nCreate one from Home or Tools.", textAlign = TextAlign.Center, color = White.copy(alpha = .65f))
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(items) { item ->
                    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.PictureAsPdf, null, tint = ComposeColor(0xFFFF6262), modifier = Modifier.size(32.dp))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(item.name, color = White, fontWeight = FontWeight.SemiBold)
                                Text("${item.file.length() / 1024} KB", color = White.copy(alpha = .6f), fontSize = 11.sp)
                            }
                            IconButton(onClick = { onShare(item.file) }) { Icon(Icons.Default.Share, null, tint = Cyan) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TextPdfScreen(value: String, onValue: (String) -> Unit, onCreate: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Text to PDF", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(value, onValue, modifier = Modifier.fillMaxWidth().weight(1f), label = { Text("Write your document") }, minLines = 8)
        Button(onClick = onCreate, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.PictureAsPdf, null); Text("  Create PDF") }
    }
}

@Composable
fun SettingsScreen() {
    Column(Modifier.fillMaxSize().padding(vertical = 18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", fontSize = 23.sp, fontWeight = FontWeight.Bold)
        listOf("App name  •  P.Cmaker", "Theme  •  Dark Purple", "Language  •  English / Hindi (UI planned)", "Privacy  •  Files stay in app storage", "Version  •  1.0 Starter").forEach {
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Text(it, Modifier.fillMaxWidth().padding(16.dp), color = White)
            }
        }
        Text("P.Cmaker is an independent editing utility. It does not create or certify official identity or banking documents.",
            color = White.copy(alpha = .55f), fontSize = 12.sp)
    }
}
